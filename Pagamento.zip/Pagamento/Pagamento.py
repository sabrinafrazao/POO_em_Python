class Pagamento:

    def processar_pagamentos():
        ...





    