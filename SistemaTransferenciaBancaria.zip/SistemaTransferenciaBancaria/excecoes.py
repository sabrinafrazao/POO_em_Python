
class SaldoInsuficienteError(Exception):
    ...

class LimiteExcedidoError(Exception):
    ...

class ContaDestinoInvalidaError(Exception):
    ...

