#!/bin/bash

zip -r "Bot_Biblioteca.zip" * -x "Bot_Biblioteca.zip"