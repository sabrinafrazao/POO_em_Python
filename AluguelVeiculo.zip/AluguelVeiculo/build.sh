#!/bin/bash

zip -r "AluguelVeiculo.zip" * -x "AluguelVeiculo.zip"