#!/bin/bash

zip -r "Bot_Pagamentos_Funcionarios.zip" * -x "Bot_Pagamentos_Funcionarios.zip"