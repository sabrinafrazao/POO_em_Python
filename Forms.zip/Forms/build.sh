#!/bin/bash

zip -r "Forms.zip" * -x "Forms.zip"